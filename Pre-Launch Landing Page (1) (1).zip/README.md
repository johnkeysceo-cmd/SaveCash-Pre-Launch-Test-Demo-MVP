
  # Pre-Launch Landing Page

  This is a code bundle for Pre-Launch Landing Page. The original project is available at https://www.figma.com/design/FoHXQCFTghbc5rm9sdJJON/Pre-Launch-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
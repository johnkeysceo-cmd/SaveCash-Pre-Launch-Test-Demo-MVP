import { motion } from "motion/react";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, ArrowLeft, Menu } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi! I'm your AI financial advisor. Ask me anything about saving money, investments, or optimizing your finances.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isThinking) return;

    const userMessage = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setIsThinking(true);

    // Generate contextual AI response based on keywords
    setTimeout(() => {
      const lowercaseMessage = userMessage.toLowerCase();
      let response = "";

      // Comprehensive response system
      if (lowercaseMessage.includes("save") || lowercaseMessage.includes("saving")) {
        response = "Based on average spending patterns, here are 3 ways to save immediately: 1) Cancel unused subscriptions ($50-200/month), 2) Negotiate your phone/internet bills (15-30% reduction), 3) Switch to a high-yield savings account (4-5% APY vs 0.01%). I can automate all of these for you.";
      } else if (lowercaseMessage.includes("invest") || lowercaseMessage.includes("401k") || lowercaseMessage.includes("retirement")) {
        response = "For investment optimization: 1) Maximize employer 401k match (free money), 2) Consider a Roth IRA for tax-free growth ($6,500/year limit, $7,500 if 50+), 3) Diversify with low-cost index funds (0.03-0.20% expense ratios). Time in market > timing the market. Want a personalized allocation strategy?";
      } else if (lowercaseMessage.includes("debt") || lowercaseMessage.includes("loan") || lowercaseMessage.includes("credit")) {
        response = "Debt elimination strategy: 1) List all debts by interest rate, 2) Pay minimums on all, extra on highest rate (avalanche method saves most), 3) Consider balance transfer to 0% APR card, 4) Negotiate lower rates with creditors. Average savings: $2,400/year on $20,000 debt. I can create your custom payoff plan.";
      } else if (lowercaseMessage.includes("budget") || lowercaseMessage.includes("expense")) {
        response = "Smart budgeting formula: 50% needs, 30% wants, 20% savings (50/30/20 rule). Track everything for 1 month to find leaks. Common savings: dining out ($200-400/month), impulse purchases ($150-300/month), unused gym memberships ($50-100/month). I'll analyze your spending and create a custom budget.";
      } else if (lowercaseMessage.includes("tax") || lowercaseMessage.includes("deduct")) {
        response = "Tax optimization strategies: 1) Max out retirement contributions (reduces taxable income), 2) HSA triple tax advantage (deductible, grows tax-free, withdrawals tax-free for medical), 3) Track all deductions (home office, mileage, education), 4) Tax-loss harvesting for investments. Average savings: $3,000-8,000/year.";
      } else if (lowercaseMessage.includes("emergency") || lowercaseMessage.includes("fund")) {
        response = "Emergency fund essentials: Target 3-6 months of expenses (6-12 months if self-employed). Keep in high-yield savings (currently 4-5% APY). Start with $1,000, then build to 1 month, then full target. Automate transfers on payday. This prevents 95% of financial emergencies.";
      } else if (lowercaseMessage.includes("mortgage") || lowercaseMessage.includes("house") || lowercaseMessage.includes("home")) {
        response = "Mortgage optimization: Current rates ~6.5-7%. Refinancing makes sense if you can reduce rate by 0.75%+. Extra principal payments save massive interest (extra $100/month on $300k = $30k+ saved). Consider 15-year vs 30-year based on goals. I can calculate your specific savings potential.";
      } else if (lowercaseMessage.includes("crypto") || lowercaseMessage.includes("bitcoin")) {
        response = "Crypto allocation: If you choose to invest, limit to 5-10% of portfolio due to volatility. Never invest more than you can afford to lose. Prioritize emergency fund + retirement accounts first. DCA (dollar-cost averaging) reduces timing risk. Secure storage is critical. Not financial advice - highly speculative asset class.";
      } else if (lowercaseMessage.includes("insurance")) {
        response = "Insurance optimization: 1) Shop rates annually (avg savings $400-800/year), 2) Increase deductibles if you have emergency fund, 3) Bundle policies for discounts, 4) Remove unnecessary coverage. Essential: health, auto, home/renters, term life (if dependents). Skip: extended warranties, mortgage insurance (if 20%+ equity).";
      } else if (lowercaseMessage.includes("college") || lowercaseMessage.includes("education") || lowercaseMessage.includes("529")) {
        response = "Education savings: 529 plans offer tax-free growth for education. Start early - $200/month from birth = $70k+ by 18 (7% return). Alternatives: Roth IRA (more flexible), UTMA/UGMA accounts. Apply for FAFSA even if you think you won't qualify. Consider community college + transfer to save $50k+.";
      } else if (lowercaseMessage.includes("subscription") || lowercaseMessage.includes("netflix") || lowercaseMessage.includes("spotify")) {
        response = "Subscription audit complete: Average person pays $273/month in subscriptions but only uses 60% of them. Common culprits: streaming ($50-80), gym ($40-60), software ($30-100), food delivery ($20-50). I can identify all your subscriptions and cancel unused ones automatically. Want me to run the audit?";
      } else if (lowercaseMessage.includes("fee") || lowercaseMessage.includes("bank") || lowercaseMessage.includes("charge")) {
        response = "Banking fee analysis: Average person pays $200-400/year in unnecessary fees. Switch to: 1) High-yield savings (4-5% vs 0.01%), 2) No-fee checking accounts, 3) Fee-free ATM networks, 4) Credit cards with rewards (not fees). I've identified $187 in monthly banking fees I can eliminate for you.";
      } else if (lowercaseMessage.includes("credit score") || lowercaseMessage.includes("fico")) {
        response = "Credit score optimization: Key factors: Payment history (35%), utilization <30% (30%), age of accounts (15%), mix (10%), new credit (10%). To improve: 1) Pay on time always, 2) Keep utilization under 10% ideally, 3) Don't close old cards, 4) Dispute errors. 700+ is good, 750+ is excellent. Takes 6-12 months to see major improvement.";
      } else if (lowercaseMessage.includes("side hustle") || lowercaseMessage.includes("extra income")) {
        response = "Side income ideas by skill level: Beginners: food delivery ($15-25/hr), tutoring ($20-50/hr), freelance writing ($25-100/hr). Advanced: consulting ($100-300/hr), course creation (passive income), rental property management. Average side hustler earns $500-2,000/month. Every extra $500/month invested = $120k+ in 10 years.";
      } else if (lowercaseMessage.includes("financial advisor") || lowercaseMessage.includes("help")) {
        response = "When to get a financial advisor: 1) Complex situations (inheritance, business sale, divorce), 2) Portfolio over $250k, 3) Need accountability. Look for fee-only (not commission), fiduciary duty, CFP certification. Costs: 0.5-1.5% of assets or $2,000-5,000/year flat fee. DIY works great for most with basic research.";
      } else {
        // Default comprehensive response
        response = `Great question! Here's what I can help you with:

💰 Savings: I can identify $500-2,500/month in hidden savings opportunities
📊 Investments: Portfolio analysis, retirement planning, and tax-efficient strategies  
💳 Debt: Custom payoff plans that save thousands in interest
📈 Budgeting: Track spending and optimize your money allocation
🏦 Banking: Eliminate fees and maximize interest earned
🎯 Goals: Create actionable plans for any financial objective

What specific area would you like me to analyze first?`;
      }

      setMessages((prev) => [...prev, { role: "assistant", content: response }]);
      setIsThinking(false);
    }, 1500);
  };

  const goBack = () => {
    window.history.pushState({}, '', '/');
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex relative overflow-hidden">
      {/* Subtle striped background pattern inspired by orchids.app */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 35px,
            rgba(168, 85, 247, 0.1) 35px,
            rgba(168, 85, 247, 0.1) 70px
          )`,
        }}
      />

      {/* Sidebar - ChatGPT inspired */}
      <motion.div
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        className="hidden md:flex w-64 bg-[#0F0F0F] border-r border-white/5 flex-col relative z-10"
      >
        <div className="p-4 border-b border-white/5">
          <Button
            onClick={goBack}
            variant="outline"
            className="w-full bg-white/5 border-white/10 text-white hover:bg-white/10 justify-start gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        <div className="flex-1 p-4 space-y-2 overflow-y-auto">
          <div className="text-sm text-gray-500 mb-4">Recent Conversations</div>
          {[
            "Savings optimization",
            "Investment strategies",
            "Subscription audit",
            "Budget planning",
          ].map((chat, i) => (
            <button
              key={i}
              className="w-full text-left p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.05] text-gray-400 text-sm transition-all duration-200 hover:text-white"
            >
              {chat}
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-white/5">
          <div className="text-xs text-gray-600 text-center">
            Powered by SaveCash AI
          </div>
        </div>
      </motion.div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative z-10">
        {/* Header */}
        <div className="bg-[#0F0F0F] border-b border-white/5 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              onClick={goBack}
              variant="ghost"
              size="icon"
              className="md:hidden text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-white">AI Financial Advisor</h1>
                <p className="text-xs text-gray-500">Always online</p>
              </div>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((message, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className={`flex gap-4 ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
              )}
              <div
                className={`max-w-2xl rounded-2xl p-4 ${
                  message.role === "user"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                    : "bg-white/[0.05] text-gray-200 border border-white/5"
                }`}
              >
                <p className="leading-relaxed">{message.content}</p>
              </div>
              {message.role === "user" && (
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm">You</span>
                </div>
              )}
            </motion.div>
          ))}

          {isThinking && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-4"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="bg-white/[0.05] rounded-2xl p-4 border border-white/5">
                <div className="flex gap-2">
                  <motion.div
                    className="w-2 h-2 rounded-full bg-purple-400"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                  />
                  <motion.div
                    className="w-2 h-2 rounded-full bg-pink-400"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                  />
                  <motion.div
                    className="w-2 h-2 rounded-full bg-orange-400"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                  />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-white/5 p-4 bg-[#0F0F0F]">
          <form onSubmit={handleSend} className="max-w-4xl mx-auto">
            <div className="flex gap-3">
              <Input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about savings, investments, fees..."
                className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-purple-500/50 focus:ring-purple-500/20 h-12 rounded-xl px-4"
                disabled={isThinking}
              />
              <Button
                type="submit"
                disabled={isThinking || !input.trim()}
                className="bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:from-purple-600 hover:via-pink-600 hover:to-orange-600 text-white px-6 h-12 rounded-xl"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-600 mt-2 text-center">
              AI can make mistakes. Verify important financial decisions.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

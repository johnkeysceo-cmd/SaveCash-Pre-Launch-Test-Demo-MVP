import { HeroSection } from "./components/HeroSection";
import { SavingsImpactSection } from "./components/SavingsImpactSection";
import { FeaturesSection } from "./components/FeaturesSection";
import { HowItWorksSection } from "./components/HowItWorksSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { AIAssistantSection } from "./components/AIAssistantSection";
import { FAQSection } from "./components/FAQSection";
import { SignupForm } from "./components/SignupForm";
import { Footer } from "./components/Footer";
import { FloatingBlobs } from "./components/FloatingBlobs";
import AIChat from "./AIChat";
import { useEffect, useState } from "react";

export default function App() {
  const [currentRoute, setCurrentRoute] = useState(window.location.pathname);

  useEffect(() => {
    const handleRouteChange = () => {
      setCurrentRoute(window.location.pathname);
    };

    window.addEventListener("popstate", handleRouteChange);
    
    // Handle initial route
    handleRouteChange();

    return () => window.removeEventListener("popstate", handleRouteChange);
  }, []);

  // Simple client-side routing
  if (currentRoute === "/ai-chat") {
    return <AIChat />;
  }

  return (
    <div className="min-h-screen bg-black overflow-hidden">
      {/* 3D Floating Blobs */}
      <FloatingBlobs />
      
      <main className="relative">
        <HeroSection />
        <SavingsImpactSection />
        <FeaturesSection />
        <HowItWorksSection />
        <TestimonialsSection />
        <AIAssistantSection />
        <FAQSection />
        <SignupForm />
        <Footer />
      </main>
    </div>
  );
}

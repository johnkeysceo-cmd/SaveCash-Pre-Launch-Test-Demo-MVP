import { motion } from "motion/react";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { 
    opacity: 1, 
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.25, 0.1, 0.25, 1],
    },
  },
};

export function Footer() {
  return (
    <footer className="py-16 px-6 border-t border-white/5 relative">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="flex flex-col items-center justify-center gap-8"
        >
          <motion.div variants={item} className="text-center">
            <motion.h3 
              className="text-3xl mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"
              initial={{ opacity: 0, y: -10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              SaveCash
            </motion.h3>
            <motion.p 
              className="text-gray-500"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              Save smarter. Live better.
            </motion.p>
          </motion.div>
        </motion.div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="mt-12 pt-8 border-t border-white/5 text-center"
        >
          <motion.p 
            variants={item}
            className="text-sm text-gray-500 mb-2"
          >
            © 2025 SaveCash
          </motion.p>
          <motion.p 
            variants={item}
            className="text-xs text-gray-600"
          >
            Bank-level security. Your data will never be sold.
          </motion.p>
        </motion.div>
      </div>
    </footer>
  );
}
